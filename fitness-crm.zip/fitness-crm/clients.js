// ========== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ВАЛИДАЦИИ ==========

// Проверка имени/фамилии (только буквы, пробелы, дефисы)
function validateName(name, fieldName) {
    const nameRegex = /^[а-яА-ЯёЁa-zA-Z\s-]+$/;
    if (!name || name.trim() === '') {
        return { valid: false, message: `${fieldName} обязательно` };
    }
    if (!nameRegex.test(name)) {
        return { valid: false, message: `${fieldName} может содержать только буквы, пробелы и дефисы` };
    }
    if (name.length > 50) {
        return { valid: false, message: `${fieldName} слишком длинное` };
    }
    return { valid: true };
}

// Проверка телефона (только 11 цифр)
function validatePhone(phone) {
    if (!phone || phone.trim() === '') {
        return { valid: false, message: 'Телефон обязателен' };
    }
    const phoneDigits = phone.replace(/\D/g, '');
    if (phoneDigits.length !== 11) {
        return { valid: false, message: 'Телефон должен содержать ровно 11 цифр' };
    }
    if (phoneDigits[0] !== '7') {
        return { valid: false, message: 'Телефон должен начинаться с 7' };
    }
    return { valid: true, digits: phoneDigits };
}

// Проверка email
function validateEmail(email) {
    if (!email || email.trim() === '') return { valid: true }; // email необязателен
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return { valid: false, message: 'Некорректный формат email' };
    }
    return { valid: true };
}

// Проверка даты окончания
function validateEndDate(date) {
    if (!date) {
        return { valid: false, message: 'Дата окончания обязательна' };
    }
    const selectedDate = new Date(date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (selectedDate < today) {
        return { valid: false, message: 'Дата окончания не может быть в прошлом' };
    }
    return { valid: true };
}

// Проверка количества посещений
function validateVisitsLeft(visits, abonementType) {
    if (abonementType === 'Безлимит') return { valid: true };
    
    if (!visits || visits === '') {
        return { valid: false, message: 'Укажите количество посещений' };
    }
    const num = parseInt(visits);
    if (isNaN(num) || num < 1 || num > 100) {
        return { valid: false, message: 'Количество посещений должно быть от 1 до 100' };
    }
    return { valid: true, value: num };
}

// ========== ЗАГРУЗКА КЛИЕНТОВ ==========
async function loadClients() {
    const tbody = document.getElementById('clients-table-body');
    const user = JSON.parse(localStorage.getItem('currentUser'));
    
    try {
        console.log('Запрашиваем клиентов с сервера...');
        const response = await fetch('http://localhost:3000/api/clients');
        const clients = await response.json();
        
        console.log('Получены клиенты:', clients);
        
        if (clients.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="8" style="text-align: center; color: #999;">
                        Нет данных о клиентах. Добавьте первого клиента.
                    </td>
                </tr>
            `;
            return;
        }
        
        let html = '';
        clients.forEach(client => {
            const endDate = new Date(client.abonement_end).toLocaleDateString('ru-RU');
            
            const actions = user && user.role === 'admin' 
                ? `<td class="admin-only">
                       <button class="edit-btn" onclick="editClient(${client.id})">✏️</button>
                       <button class="delete-btn" onclick="deleteClient(${client.id})">🗑️</button>
                   </td>`
                : '<td></td>';
            
            html += `
                <tr>
                    <td>${client.id}</td>
                    <td>${client.last_name}</td>
                    <td>${client.first_name}</td>
                    <td>${client.phone || '-'}</td>
                    <td>${client.abonement_type}</td>
                    <td>${endDate}</td>
                    <td>${client.visits_left !== null ? client.visits_left : '∞'}</td>
                    ${actions}
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
        
    } catch (error) {
        console.error('Ошибка при загрузке клиентов:', error);
        tbody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align: center; color: red;">
                    Ошибка загрузки данных. Проверьте сервер.
                </td>
            </tr>
        `;
    }
}

// ========== ПОКАЗ ФОРМЫ ДОБАВЛЕНИЯ ==========
function showAddClientForm() {
    document.getElementById('add-client-form').style.display = 'block';
    document.getElementById('add-client-form').scrollIntoView({ behavior: 'smooth' });
}

// ========== ОТМЕНА ДОБАВЛЕНИЯ ==========
function cancelAddClient() {
    document.getElementById('add-client-form').style.display = 'none';
    document.getElementById('client-form').reset();
    // Убираем красные рамки
    document.querySelectorAll('.input-error').forEach(el => {
        el.classList.remove('input-error');
    });
}

// ========== СОХРАНЕНИЕ НОВОГО КЛИЕНТА ==========
async function saveNewClient() {
    // Получаем значения
    const lastName = document.getElementById('last_name').value;
    const firstName = document.getElementById('first_name').value;
    const phone = document.getElementById('phone').value;
    const abonementType = document.getElementById('abonement_type').value;
    const endDate = document.getElementById('abonement_end').value;
    const visitsLeft = document.getElementById('visits_left').value;
    
    // Убираем все предыдущие ошибки
    document.querySelectorAll('.input-error').forEach(el => {
        el.classList.remove('input-error');
    });
    
    // Валидация
    const lastNameCheck = validateName(lastName, 'Фамилия');
    if (!lastNameCheck.valid) {
        document.getElementById('last_name').classList.add('input-error');
        alert(lastNameCheck.message);
        return;
    }
    
    const firstNameCheck = validateName(firstName, 'Имя');
    if (!firstNameCheck.valid) {
        document.getElementById('first_name').classList.add('input-error');
        alert(firstNameCheck.message);
        return;
    }
    
    const phoneCheck = validatePhone(phone);
    if (!phoneCheck.valid) {
        document.getElementById('phone').classList.add('input-error');
        alert(phoneCheck.message);
        return;
    }
    
    if (!abonementType) {
        document.getElementById('abonement_type').classList.add('input-error');
        alert('Выберите тип абонемента');
        return;
    }
    
    const dateCheck = validateEndDate(endDate);
    if (!dateCheck.valid) {
        document.getElementById('abonement_end').classList.add('input-error');
        alert(dateCheck.message);
        return;
    }
    
    const visitsCheck = validateVisitsLeft(visitsLeft, abonementType);
    if (!visitsCheck.valid) {
        document.getElementById('visits_left').classList.add('input-error');
        alert(visitsCheck.message);
        return;
    }
    
    const emailCheck = validateEmail(document.getElementById('email').value);
    if (!emailCheck.valid) {
        document.getElementById('email').classList.add('input-error');
        alert(emailCheck.message);
        return;
    }
    
    // Собираем данные
    const newClient = {
        last_name: lastName,
        first_name: firstName,
        middle_name: document.getElementById('middle_name').value || null,
        phone: phoneCheck.digits,
        email: document.getElementById('email').value || null,
        abonement_type: abonementType,
        abonement_end: endDate,
        visits_left: visitsCheck.value || null
    };
    
    try {
        const response = await fetch('http://localhost:3000/api/clients', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newClient)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Ошибка при сохранении');
        }

        cancelAddClient();
        await loadClients();
        alert('✅ Клиент успешно добавлен!');
        
    } catch (error) {
        console.error('Ошибка:', error);
        alert('❌ ' + error.message);
    }
}

// ========== РЕДАКТИРОВАНИЕ КЛИЕНТА ==========
async function editClient(id) {
    try {
        const response = await fetch(`http://localhost:3000/api/clients/${id}`);
        const client = await response.json();
        
        if (!client) {
            alert('Клиент не найден');
            return;
        }
        
        document.getElementById('edit_client_id').value = client.id;
        document.getElementById('edit_last_name').value = client.last_name || '';
        document.getElementById('edit_first_name').value = client.first_name || '';
        document.getElementById('edit_middle_name').value = client.middle_name || '';
        document.getElementById('edit_phone').value = client.phone || '';
        document.getElementById('edit_email').value = client.email || '';
        document.getElementById('edit_abonement_type').value = client.abonement_type || '';
        
        if (client.abonement_end) {
            const date = new Date(client.abonement_end);
            const formattedDate = date.toISOString().split('T')[0];
            document.getElementById('edit_abonement_end').value = formattedDate;
        }
        
        document.getElementById('edit_visits_left').value = client.visits_left || '';
        
        document.getElementById('edit-client-form').style.display = 'block';
        document.getElementById('edit-client-form').scrollIntoView({ behavior: 'smooth' });
        
    } catch (error) {
        console.error('Ошибка загрузки данных клиента:', error);
        alert('Не удалось загрузить данные клиента');
    }
}

// ========== ОТМЕНА РЕДАКТИРОВАНИЯ ==========
function cancelEditClient() {
    document.getElementById('edit-client-form').style.display = 'none';
    document.getElementById('edit-client-form-fields').reset();
    document.querySelectorAll('.input-error').forEach(el => {
        el.classList.remove('input-error');
    });
}

// ========== СОХРАНЕНИЕ ИЗМЕНЕНИЙ ==========
async function saveEditedClient() {
    const id = document.getElementById('edit_client_id').value;
    
    const lastName = document.getElementById('edit_last_name').value;
    const firstName = document.getElementById('edit_first_name').value;
    const phone = document.getElementById('edit_phone').value;
    const abonementType = document.getElementById('edit_abonement_type').value;
    const endDate = document.getElementById('edit_abonement_end').value;
    const visitsLeft = document.getElementById('edit_visits_left').value;
    
    // Убираем все предыдущие ошибки
    document.querySelectorAll('.input-error').forEach(el => {
        el.classList.remove('input-error');
    });
    
    // Валидация
    const lastNameCheck = validateName(lastName, 'Фамилия');
    if (!lastNameCheck.valid) {
        document.getElementById('edit_last_name').classList.add('input-error');
        alert(lastNameCheck.message);
        return;
    }
    
    const firstNameCheck = validateName(firstName, 'Имя');
    if (!firstNameCheck.valid) {
        document.getElementById('edit_first_name').classList.add('input-error');
        alert(firstNameCheck.message);
        return;
    }

    // Проверка отчества
    const middleNameCheck = validateMiddleName(document.getElementById('edit_middle_name').value);
    if (!middleNameCheck.valid) {
        document.getElementById('edit_middle_name').classList.add('input-error');
        alert(middleNameCheck.message);
        return;
    }   
    
    const phoneCheck = validatePhone(phone);
    if (!phoneCheck.valid) {
        document.getElementById('edit_phone').classList.add('input-error');
        alert(phoneCheck.message);
        return;
    }
    
    if (!abonementType) {
        document.getElementById('edit_abonement_type').classList.add('input-error');
        alert('Выберите тип абонемента');
        return;
    }
    
    const dateCheck = validateEndDate(endDate);
    if (!dateCheck.valid) {
        document.getElementById('edit_abonement_end').classList.add('input-error');
        alert(dateCheck.message);
        return;
    }
    
    const visitsCheck = validateVisitsLeft(visitsLeft, abonementType);
    if (!visitsCheck.valid) {
        document.getElementById('edit_visits_left').classList.add('input-error');
        alert(visitsCheck.message);
        return;
    }
    
    const emailCheck = validateEmail(document.getElementById('edit_email').value);
    if (!emailCheck.valid) {
        document.getElementById('edit_email').classList.add('input-error');
        alert(emailCheck.message);
        return;
    }
    
    const updatedClient = {
        last_name: lastName,
        first_name: firstName,
        middle_name: document.getElementById('edit_middle_name').value || null,
        phone: phoneCheck.digits,
        email: document.getElementById('edit_email').value || null,
        abonement_type: abonementType,
        abonement_end: endDate,
        visits_left: visitsCheck.value || null
    };
    
    try {
        const response = await fetch(`http://localhost:3000/api/clients/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedClient)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            alert('Ошибка: ' + (data.error || 'Неизвестная ошибка'));
            return;
        }
        
        cancelEditClient();
        await loadClients();
        alert('✅ Данные клиента обновлены');
        
    } catch (error) {
        console.error('Ошибка:', error);
        alert('❌ Ошибка соединения с сервером');
    }
}
// Проверка отчества (необязательное поле)
function validateMiddleName(name) {
    // Если отчество не заполнено - пропускаем
    if (!name || name.trim() === '') {
        return { valid: true };
    }
    
    const nameRegex = /^[а-яА-ЯёЁa-zA-Z\s-]+$/;
    
    // Проверка на допустимые символы
    if (!nameRegex.test(name)) {
        return { valid: false, message: 'Отчество может содержать только буквы, пробелы и дефисы' };
    }
    
    // Проверка длины
    if (name.length > 50) {
        return { valid: false, message: 'Отчество слишком длинное' };
    }
    
    return { valid: true };
}
// ========== УДАЛЕНИЕ КЛИЕНТА ==========
async function deleteClient(id) {
    if (!confirm('Вы уверены, что хотите удалить этого клиента?')) {
        return;
    }
    
    try {
        const response = await fetch(`http://localhost:3000/api/clients/${id}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Ошибка при удалении');
        }
        
        await loadClients();
        alert('✅ Клиент удален');
        
    } catch (error) {
        console.error('Ошибка:', error);
        alert('❌ ' + error.message);
    }
}

// ========== ИНИЦИАЛИЗАЦИЯ ==========
document.addEventListener('DOMContentLoaded', function() {
    console.log('Страница клиентов загружена');
    loadClients();
});