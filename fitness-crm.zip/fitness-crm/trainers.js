// Временный файл для страницы тренеров
document.addEventListener('DOMContentLoaded', function() {
    const tbody = document.getElementById('trainers-table-body');
    
    tbody.innerHTML = `
        <tr>
            <td colspan="5" style="text-align: center; color: #999;">
                Данные будут загружаться из базы PostgreSQL на следующем этапе
            </td>
        </tr>
    `;
});

// Функция для подсчета загрузки тренеров (будет реализована позже)
function calculateTrainerLoad() {
    alert('Функция подсчета загрузки будет подключена после настройки базы данных');
}// Функция для загрузки тренеров и их загрузки
async function loadTrainers() {
    const tbody = document.getElementById('trainers-table-body');
    const user = JSON.parse(localStorage.getItem('currentUser'));
    
    if (!user) {
        window.location.href = 'index.html';
        return;
    }
    
    try {
        console.log('Запрашиваем загрузку тренеров...');
        const response = await fetch('http://localhost:3000/api/trainer-load');
        const trainers = await response.json();
        
        console.log('Получены данные:', trainers);
        
        if (trainers.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; color: #999;">
                        Нет данных о тренерах. Добавьте тренеров в базу данных.
                    </td>
                </tr>
            `;
            return;
        }
        
        // Формируем строки таблицы
        let html = '';
        trainers.forEach(trainer => {
            // Определяем цвет для количества тренировок
            let countColor = 'black';
            if (trainer.training_count > 10) countColor = 'green';
            if (trainer.training_count > 20) countColor = 'darkgreen';
            if (trainer.training_count < 3) countColor = 'orange';
            if (trainer.training_count === 0) countColor = 'gray';
            
            html += `
                <tr>
                    <td>${trainer.id}</td>
                    <td>${trainer.last_name}</td>
                    <td>${trainer.first_name}</td>
                    <td>${trainer.specialization}</td>
                    <td style="color: ${countColor}; font-weight: bold; text-align: center;">
                        ${trainer.training_count || 0}
                    </td>
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
        
    } catch (error) {
        console.error('Ошибка при загрузке тренеров:', error);
        tbody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align: center; color: red;">
                    Ошибка загрузки данных. Убедитесь, что сервер запущен.
                    <br>
                    <small>${error.message}</small>
                </td>
            </tr>
        `;
    }
}

// Функция обновления статистики
async function calculateTrainerLoad() {
    await loadTrainers();
    alert('Статистика обновлена!');
}

// Загружаем данные при открытии страницы
document.addEventListener('DOMContentLoaded', function() {
    console.log('Страница тренеров загружена');
    loadTrainers();
});