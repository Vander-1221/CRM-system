
function generateCaptcha() {
    let num1 = Math.floor(Math.random() * 10) + 1; 
    let num2 = Math.floor(Math.random() * 10) + 1;
    document.getElementById('captcha-num1').textContent = num1;
    document.getElementById('captcha-num2').textContent = num2;
    document.getElementById('captcha-result').value = num1 + num2;
    document.getElementById('captcha-answer').value = '';
    document.getElementById('captcha_error').style.display = 'none';
}

// ========== ВАЛИДАЦИЯ ПОЛЕЙ ==========

// Проверка фамилии (только буквы)
function validateLastName() {
    const input = document.getElementById('last_name');
    const error = document.getElementById('last_name_error');
    const value = input.value.trim();
    
    const nameRegex = /^[а-яА-ЯёЁa-zA-Z\s-]+$/;
    
    if (value === '') {
        error.textContent = 'Фамилия обязательна';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else if (!nameRegex.test(value)) {
        error.textContent = 'Фамилия может содержать только буквы, пробелы и дефисы';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else {
        error.style.display = 'none';
        input.classList.remove('input-error');
        return true;
    }
}

// Проверка имени (только буквы)
function validateFirstName() {
    const input = document.getElementById('first_name');
    const error = document.getElementById('first_name_error');
    const value = input.value.trim();
    
    const nameRegex = /^[а-яА-ЯёЁa-zA-Z\s-]+$/;
    
    if (value === '') {
        error.textContent = 'Имя обязательно';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else if (!nameRegex.test(value)) {
        error.textContent = 'Имя может содержать только буквы, пробелы и дефисы';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else {
        error.style.display = 'none';
        input.classList.remove('input-error');
        return true;
    }
}

// Проверка телефона (только цифры и формат)
function validatePhone() {
    const input = document.getElementById('phone');
    const error = document.getElementById('phone_error');
    let value = input.value.replace(/\D/g, ''); // удаляем всё кроме цифр
    
    // Форматируем телефон по мере ввода
    if (value.length > 0) {
        if (value.length <= 1) {
            value = '+7' + value;
        } else if (value.length <= 4) {
            value = '+7 (' + value.substring(1);
        } else if (value.length <= 7) {
            value = '+7 (' + value.substring(1, 4) + ') ' + value.substring(4);
        } else if (value.length <= 9) {
            value = '+7 (' + value.substring(1, 4) + ') ' + value.substring(4, 7) + '-' + value.substring(7);
        } else {
            value = '+7 (' + value.substring(1, 4) + ') ' + value.substring(4, 7) + '-' + value.substring(7, 9) + '-' + value.substring(9, 11);
        }
        input.value = value;
    }
    
    // Проверяем количество цифр (11 цифр: 7 + 10)
    const digits = input.value.replace(/\D/g, '');
    if (digits.length === 0) {
        error.textContent = 'Телефон обязателен';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else if (digits.length !== 11) {
        error.textContent = 'Введите полный номер (11 цифр)';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else {
        error.style.display = 'none';
        input.classList.remove('input-error');
        return true;
    }
}

// Проверка логина
function validateUsername() {
    const input = document.getElementById('username');
    const error = document.getElementById('username_error');
    const value = input.value.trim();
    
    const usernameRegex = /^[a-zA-Z0-9_]{4,20}$/;
    
    if (value === '') {
        error.textContent = 'Логин обязателен';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else if (!usernameRegex.test(value)) {
        error.textContent = 'Логин должен содержать 4-20 символов (буквы, цифры, _)';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else {
        error.style.display = 'none';
        input.classList.remove('input-error');
        return true;
    }
}

// Проверка пароля и его сложности
function validatePassword() {
    const input = document.getElementById('password');
    const error = document.getElementById('password_error');
    const value = input.value;
    
    const strengthBar = document.getElementById('password-strength-bar');
    
    // Убираем классы силы
    strengthBar.className = 'password-strength-bar';
    
    if (value.length === 0) {
        error.textContent = 'Пароль обязателен';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else if (value.length < 6) {
        error.textContent = 'Пароль должен быть не менее 6 символов';
        error.style.display = 'block';
        input.classList.add('input-error');
        strengthBar.classList.add('strength-weak');
        return false;
    } else {
        // Оценка сложности пароля
        let strength = 0;
        if (value.length >= 8) strength++;
        if (value.match(/[a-z]/)) strength++;
        if (value.match(/[A-Z]/)) strength++;
        if (value.match(/[0-9]/)) strength++;
        if (value.match(/[^a-zA-Z0-9]/)) strength++;
        
        if (strength <= 2) {
            strengthBar.classList.add('strength-weak');
        } else if (strength <= 4) {
            strengthBar.classList.add('strength-medium');
        } else {
            strengthBar.classList.add('strength-strong');
        }
        
        error.style.display = 'none';
        input.classList.remove('input-error');
        return true;
    }
}

// Проверка подтверждения пароля
function validateConfirmPassword() {
    const password = document.getElementById('password').value;
    const confirm = document.getElementById('confirm_password').value;
    const error = document.getElementById('confirm_password_error');
    const input = document.getElementById('confirm_password');
    
    if (confirm === '') {
        error.textContent = 'Подтвердите пароль';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else if (password !== confirm) {
        error.textContent = 'Пароли не совпадают';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else {
        error.style.display = 'none';
        input.classList.remove('input-error');
        return true;
    }
}

// Проверка капчи
function validateCaptcha() {
    const answer = document.getElementById('captcha-answer').value;
    const correct = document.getElementById('captcha-result').value;
    const error = document.getElementById('captcha_error');
    const input = document.getElementById('captcha-answer');
    
    if (answer === '') {
        error.textContent = 'Решите пример';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else if (parseInt(answer) !== parseInt(correct)) {
        error.textContent = 'Неверный ответ';
        error.style.display = 'block';
        input.classList.add('input-error');
        return false;
    } else {
        error.style.display = 'none';
        input.classList.remove('input-error');
        return true;
    }
}

// ========== РЕГИСТРАЦИЯ ==========
async function registerUser() {
    // Проверяем все поля
    const isLastNameValid = validateLastName();
    const isFirstNameValid = validateFirstName();
    const isPhoneValid = validatePhone();
    const isUsernameValid = validateUsername();
    const isPasswordValid = validatePassword();
    const isConfirmValid = validateConfirmPassword();
    const isCaptchaValid = validateCaptcha();
    
    if (!isLastNameValid || !isFirstNameValid || !isPhoneValid || 
        !isUsernameValid || !isPasswordValid || !isConfirmValid || !isCaptchaValid) {
        alert('Исправьте ошибки в форме');
        return;
    }
    
    // Собираем данные
    const userData = {
        last_name: document.getElementById('last_name').value.trim(),
        first_name: document.getElementById('first_name').value.trim(),
        middle_name: '', // пока не используем
        phone: document.getElementById('phone').value.replace(/\D/g, ''),
        email: document.getElementById('email').value || null,
        username: document.getElementById('username').value.trim(),
        password: document.getElementById('password').value,
        role: 'user' // по умолчанию обычный пользователь
    };
    
    try {
        // Отправляем на сервер
        const response = await fetch('http://localhost:3000/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData)
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Ошибка регистрации');
        }
        
        const result = await response.json();
        
        // Показываем модальное окно с данными пользователя
        showSuccessModal(userData); // ← здесь userData определена
        
        // Очищаем форму
        document.getElementById('register-form').reset();
        generateCaptcha(); // обновляем капчу
        
    } catch (error) {
        console.error('Ошибка регистрации:', error);
        alert('Ошибка: ' + error.message);
    }
}

// Функция для дополнительной проверки на стороне клиента
function sanitizeClientSide(input) {
    if (!input) return input;
    
    // Удаляем HTML-теги
    let clean = input.replace(/<[^>]*>/g, '');
    
    // Удаляем потенциально опасные символы
    clean = clean.replace(/[<>'";]/g, '');
    
    return clean;
}

// ========== МОДАЛЬНОЕ ОКНО ==========

// Показать модальное окно с информацией о пользователе
function showSuccessModal(userData) {
    const modal = document.getElementById('successModal');
    const userInfo = document.getElementById('modal-user-info');
    
    // Формируем приветственное сообщение
    userInfo.innerHTML = `👤 ${userData.last_name} ${userData.first_name}<br>🔑 Логин: ${userData.username}`;
    
    // Показываем модальное окно
    modal.style.display = 'block';
    
    // Блокируем прокрутку страницы
    document.body.style.overflow = 'hidden';
}

// Закрыть модальное окно
function closeModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Перенаправление на страницу входа
function redirectToLogin() {
    closeModal();
    window.location.href = 'index.html';
}

// Закрытие по клику вне модального окна
window.onclick = function(event) {
    const modal = document.getElementById('successModal');
    if (event.target === modal) {
        closeModal();
    }
}

// Закрытие по клавише Escape
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeModal();
    }
});