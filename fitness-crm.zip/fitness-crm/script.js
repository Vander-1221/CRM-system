// Функция для входа в систему
function login() {
    // Получаем значения из полей ввода
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');
    
    // Очищаем предыдущее сообщение об ошибке
    errorMessage.textContent = '';
    
    // Проверяем логин и пароль
    if (username === 'admin' && password === 'admin123') {
        // Сохраняем информацию о пользователе
        const user = {
            username: 'admin',
            role: 'admin'
        };
        localStorage.setItem('currentUser', JSON.stringify(user));
        
        // Перенаправляем на страницу клиентов
        window.location.href = 'clients.html';
    } 
    else if (username === 'user' && password === 'user123') {
        // Сохраняем информацию о пользователе
        const user = {
            username: 'user',
            role: 'user'
        };
        localStorage.setItem('currentUser', JSON.stringify(user));
        
        // Перенаправляем на страницу клиентов
        window.location.href = 'clients.html';
    } 
    else {
        // Показываем сообщение об ошибке
        errorMessage.textContent = 'Неверный логин или пароль';
    }
}

// Функция для проверки авторизации при загрузке страницы
function checkAccess() {
    const userJson = localStorage.getItem('currentUser');
    
    // Если пользователь не авторизован, отправляем на страницу входа
    if (!userJson && !window.location.href.includes('index.html')) {
        window.location.href = 'index.html';
        return null;
    }
    
    return userJson ? JSON.parse(userJson) : null;
}

// Функция для выхода из системы
function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = 'index.html';
}

// Функция для отображения информации о пользователе
function displayUserInfo() {
    const user = checkAccess();
    if (user) {
        const userInfo = document.getElementById('user-info');
        if (userInfo) {
            userInfo.textContent = `Пользователь: ${user.username} (${user.role === 'admin' ? 'Администратор' : 'Пользователь'})`;
        }
    }
}

// Функция для обновления интерфейса в зависимости от роли
function updateUIBasedOnRole() {
    const user = checkAccess();
    if (!user) return;
    
    const adminElements = document.querySelectorAll('.admin-only');
    
    if (user.role !== 'admin') {
        adminElements.forEach(el => {
            el.style.display = 'none';
        });
    }
}

// Вызываем при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Не проверяем доступ на странице входа
    if (!window.location.href.includes('index.html')) {
        displayUserInfo();
        updateUIBasedOnRole();
    }
});