// Загрузка списка тренировок
async function loadTrainings() {
    const tbody = document.getElementById('trainings-table-body');
    const user = JSON.parse(localStorage.getItem('currentUser'));
    
    if (!user) {
        window.location.href = 'index.html';
        return;
    }
    
    try {
        console.log('Запрашиваем тренировки...');
        const response = await fetch('http://localhost:3000/api/trainings');
        const trainings = await response.json();
        
        console.log('Получены тренировки:', trainings);
        
        if (trainings.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; color: #999;">
                        Нет запланированных тренировок. Создайте первую запись.
                    </td>
                </tr>
            `;
            return;
        }
        
        // Формируем строки таблицы
        let html = '';
        trainings.forEach(training => {
            const date = new Date(training.training_date).toLocaleDateString('ru-RU');
            
            let statusColor = 'black';
            let statusText = training.status;
            if (training.status === 'scheduled') {
                statusColor = 'blue';
                statusText = 'Запланирована';
            } else if (training.status === 'completed') {
                statusColor = 'green';
                statusText = 'Проведена';
            } else if (training.status === 'cancelled') {
                statusColor = 'red';
                statusText = 'Отменена';
            }
            
            const actions = user.role === 'admin' 
                ? `<td>
                       <button class="edit-btn" onclick="editTraining(${training.id})">✏️</button>
                       <button class="delete-btn" onclick="deleteTraining(${training.id})">🗑️</button>
                       <select onchange="updateTrainingStatus(${training.id}, this.value)" style="margin-left: 5px; padding: 3px;">
                           <option value="scheduled" ${training.status === 'scheduled' ? 'selected' : ''}>Запл.</option>
                           <option value="completed" ${training.status === 'completed' ? 'selected' : ''}>Провед.</option>
                           <option value="cancelled" ${training.status === 'cancelled' ? 'selected' : ''}>Отмен.</option>
                       </select>
                   </td>`
                : '<td></td>';
            
            html += `
                <tr>
                    <td>${date}</td>
                    <td>${training.training_time}</td>
                    <td>${training.client_last_name} ${training.client_first_name}</td>
                    <td>${training.trainer_last_name} ${training.trainer_first_name}</td>
                    <td style="color: ${statusColor}; font-weight: bold;">${statusText}</td>
                    ${actions}
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
        
    } catch (error) {
        console.error('Ошибка при загрузке тренировок:', error);
        tbody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; color: red;">
                    Ошибка загрузки данных. Убедитесь, что сервер запущен.
                </td>
            </tr>
        `;
    }
}

// ========== ФУНКЦИИ ВАЛИДАЦИИ ==========

// Проверка даты тренировки
function validateTrainingDate(date) {
    if (!date) {
        return { valid: false, message: 'Дата тренировки обязательна' };
    }
    
    const trainingDate = new Date(date);
    trainingDate.setHours(0, 0, 0, 0);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Дата не может быть в прошлом
    if (trainingDate < today) {
        return { valid: false, message: 'Дата тренировки не может быть в прошлом' };
    }
    
    // Дата не может быть более чем через год (опционально)
    const nextYear = new Date();
    nextYear.setFullYear(nextYear.getFullYear() + 1);
    if (trainingDate > nextYear) {
        return { valid: false, message: 'Дата тренировки не может быть более чем через год' };
    }
    
    return { valid: true };
}

// Проверка времени тренировки
function validateTrainingTime(time) {
    if (!time) {
        return { valid: false, message: 'Время тренировки обязательно' };
    }
    
    const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;
    if (!timeRegex.test(time)) {
        return { valid: false, message: 'Некорректный формат времени' };
    }
    
    return { valid: true };
}

// Проверка выбора клиента и тренера
function validateSelect(value, fieldName) {
    if (!value || value === '') {
        return { valid: false, message: `Выберите ${fieldName}` };
    }
    return { valid: true };
}

// Проверка заметок (ограничение длины)
function validateNotes(notes) {
    if (notes && notes.length > 500) {
        return { valid: false, message: 'Заметки слишком длинные (макс. 500 символов)' };
    }
    return { valid: true };
}

// Показать форму добавления тренировки
async function showAddTrainingForm() {
    document.getElementById('add-training-form').style.display = 'block';
    
    // Загружаем список клиентов и тренеров для выпадающих списков
    await loadClientsForSelect();
    await loadTrainersForSelect();
    
    document.getElementById('add-training-form').scrollIntoView({ behavior: 'smooth' });
}

// Загрузка клиентов для выпадающего списка
async function loadClientsForSelect() {
    try {
        const response = await fetch('http://localhost:3000/api/clients');
        const clients = await response.json();
        
        const select = document.getElementById('training_client_id');
        select.innerHTML = '<option value="">Выберите клиента</option>';
        
        clients.forEach(client => {
            select.innerHTML += `<option value="${client.id}">${client.last_name} ${client.first_name} (${client.abonement_type})</option>`;
        });
    } catch (error) {
        console.error('Ошибка загрузки клиентов:', error);
    }
}


// Загрузка тренеров для выпадающего списка
async function loadTrainersForSelect() {
    try {
        const response = await fetch('http://localhost:3000/api/trainers');
        const trainers = await response.json();
        
        const select = document.getElementById('training_trainer_id');
        select.innerHTML = '<option value="">Выберите тренера</option>';
        
        trainers.forEach(trainer => {
            select.innerHTML += `<option value="${trainer.id}">${trainer.last_name} ${trainer.first_name} (${trainer.specialization})</option>`;
        });
    } catch (error) {
        console.error('Ошибка загрузки тренеров:', error);
    }
}

// Отмена добавления тренировки
function cancelAddTraining() {
    document.getElementById('add-training-form').style.display = 'none';
    document.getElementById('training-form').reset();
    document.getElementById('abonement-check-result').style.display = 'none';
}

// Проверка, свободен ли тренер в указанное время (с учетом интервала)
async function checkTrainerAvailability(trainerId, date, time, excludeTrainingId = null) {
    try {
        const response = await fetch('http://localhost:3000/api/check-trainer-availability', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                trainer_id: trainerId,
                training_date: date,
                training_time: time,
                exclude_training_id: excludeTrainingId
            })
        });
        
        const result = await response.json();
        return result;
        
    } catch (error) {
        console.error('Ошибка проверки доступности:', error);
        return { available: false, error: 'Ошибка проверки' };
    }
}

// Проверка абонемента и сохранение тренировки
// Проверка абонемента и сохранение тренировки
async function checkAbonementAndSave() {
    const clientId = document.getElementById('training_client_id').value;
    const date = document.getElementById('training_date').value;
    const time = document.getElementById('training_time').value;
    const trainerId = document.getElementById('training_trainer_id').value;
    const notes = document.getElementById('training_notes').value;
    
    document.querySelectorAll('.input-error').forEach(el => {
        el.classList.remove('input-error');
    });
    
    const dateCheck = validateTrainingDate(date);
    if (!dateCheck.valid) {
        document.getElementById('training_date').classList.add('input-error');
        alert(dateCheck.message);
        return;
    }
    
    const timeCheck = validateTrainingTime(time);
    if (!timeCheck.valid) {
        document.getElementById('training_time').classList.add('input-error');
        alert(timeCheck.message);
        return;
    }
    
    const clientCheck = validateSelect(clientId, 'клиента');
    if (!clientCheck.valid) {
        document.getElementById('training_client_id').classList.add('input-error');
        alert(clientCheck.message);
        return;
    }
    
    const trainerCheck = validateSelect(trainerId, 'тренера');
    if (!trainerCheck.valid) {
        document.getElementById('training_trainer_id').classList.add('input-error');
        alert(trainerCheck.message);
        return;
    }
    
    const notesCheck = validateNotes(notes);
    if (!notesCheck.valid) {
        document.getElementById('training_notes').classList.add('input-error');
        alert(notesCheck.message);
        return;
    }
    
    const resultDiv = document.getElementById('abonement-check-result');
    
    try {
        // 1. Проверяем абонемент
        const checkResponse = await fetch(`http://localhost:3000/api/check-abonement/${clientId}`);
        const checkResult = await checkResponse.json();
        
        if (!checkResult.valid) {
            resultDiv.style.display = 'block';
            resultDiv.style.backgroundColor = '#ffebee';
            resultDiv.style.color = '#c62828';
            resultDiv.innerHTML = `<strong>❌ Ошибка:</strong> ${checkResult.reason}`;
            return;
        }
        
        // 2. НОВОЕ: Проверяем, свободен ли тренер
        // Проверяем, свободен ли тренер
        const availabilityCheck = await checkTrainerAvailability(trainerId, date, time);

        if (!availabilityCheck.available) {
            resultDiv.style.display = 'block';
            resultDiv.style.backgroundColor = '#ffebee';
            resultDiv.style.color = '#c62828';
            resultDiv.innerHTML = `<strong>❌ Ошибка:</strong> ${availabilityCheck.message || 'Тренер уже занят в это время. Нужно соблюдать интервал в 1 час между тренировками.'}`;
            return;
        }
        
        // 3. Если абонемент активен и тренер свободен, создаем тренировку
        const trainingData = {
            training_date: date,
            training_time: time,
            client_id: clientId,
            trainer_id: trainerId,
            notes: notes
        };
        
        const saveResponse = await fetch('http://localhost:3000/api/trainings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(trainingData)
        });
        
        if (!saveResponse.ok) {
            throw new Error('Ошибка при сохранении');
        }
        
        resultDiv.style.display = 'block';
        resultDiv.style.backgroundColor = '#e8f5e8';
        resultDiv.style.color = '#2e7d32';
        resultDiv.innerHTML = '<strong>✅ Успех:</strong> Тренировка запланирована!';
        
        setTimeout(() => {
            cancelAddTraining();
            loadTrainings();
        }, 1500);
        
    } catch (error) {
        console.error('Ошибка:', error);
        resultDiv.style.display = 'block';
        resultDiv.style.backgroundColor = '#ffebee';
        resultDiv.style.color = '#c62828';
        resultDiv.innerHTML = `<strong>❌ Ошибка:</strong> ${error.message}`;
    }
}

// Обновление статуса тренировки
async function updateTrainingStatus(id, status) {
    try {
        const response = await fetch(`http://localhost:3000/api/trainings/${id}/status`, {  // добавили /status
            method: 'PATCH',  // поменяли с PUT на PATCH
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ status })
        });
        
        if (!response.ok) {
            throw new Error('Ошибка обновления');
        }
        
        await loadTrainings();
        
    } catch (error) {
        console.error('Ошибка:', error);
        alert('Не удалось обновить статус');
    }
}

// Заглушки для будущих функций
function editTraining(id) {
    alert(`Редактирование тренировки ${id} будет реализовано позже`);
}

// Удаление тренировки
async function deleteTraining(id) {
    if (!confirm('Вы уверены, что хотите удалить эту тренировку?')) {
        return;
    }
    
    try {
        const response = await fetch(`http://localhost:3000/api/trainings/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Ошибка при удалении');
        }
        
        await loadTrainings();
        alert('Тренировка удалена');
        
    } catch (error) {
        console.error('Ошибка:', error);
        alert('Не удалось удалить тренировку: ' + error.message);
    }
}

// Загружаем тренировки при открытии страницы
document.addEventListener('DOMContentLoaded', function() {
    loadTrainings();
    
});

// Редактирование тренировки - загрузка данных в форму
async function editTraining(id) {
    try {
        // Загружаем списки клиентов и тренеров для выпадающих списков
        await loadClientsForEditSelect();
        await loadTrainersForEditSelect();
        
        // Получаем данные тренировки
        const response = await fetch(`http://localhost:3000/api/trainings/${id}`);
        const training = await response.json();
        
        if (!training) {
            alert('Тренировка не найдена');
            return;
        }
        
        // Заполняем форму
        document.getElementById('edit_training_id').value = training.id;
        document.getElementById('edit_training_date').value = training.training_date;
        document.getElementById('edit_training_time').value = training.training_time;
        document.getElementById('edit_training_client_id').value = training.client_id;
        document.getElementById('edit_training_trainer_id').value = training.trainer_id;
        document.getElementById('edit_training_status').value = training.status;
        document.getElementById('edit_training_notes').value = training.notes || '';
        
        // Показываем форму
        document.getElementById('edit-training-form').style.display = 'block';
        document.getElementById('edit-training-form').scrollIntoView({ behavior: 'smooth' });
        
    } catch (error) {
        console.error('Ошибка загрузки данных тренировки:', error);
        alert('Не удалось загрузить данные тренировки');
    }
}

// Загрузка клиентов для выпадающего списка в форме редактирования
async function loadClientsForEditSelect() {
    try {
        const response = await fetch('http://localhost:3000/api/clients');
        const clients = await response.json();
        
        const select = document.getElementById('edit_training_client_id');
        select.innerHTML = '<option value="">Выберите клиента</option>';
        
        clients.forEach(client => {
            select.innerHTML += `<option value="${client.id}">${client.last_name} ${client.first_name} (${client.abonement_type})</option>`;
        });
    } catch (error) {
        console.error('Ошибка загрузки клиентов:', error);
    }
}

// Загрузка тренеров для выпадающего списка в форме редактирования
async function loadTrainersForEditSelect() {
    try {
        const response = await fetch('http://localhost:3000/api/trainers');
        const trainers = await response.json();
        
        const select = document.getElementById('edit_training_trainer_id');
        select.innerHTML = '<option value="">Выберите тренера</option>';
        
        trainers.forEach(trainer => {
            select.innerHTML += `<option value="${trainer.id}">${trainer.last_name} ${trainer.first_name} (${trainer.specialization})</option>`;
        });
    } catch (error) {
        console.error('Ошибка загрузки тренеров:', error);
    }
}

// Отмена редактирования
function cancelEditTraining() {
    document.getElementById('edit-training-form').style.display = 'none';
    document.getElementById('edit-training-form-fields').reset();
}

// Сохранение изменений тренировки
// Сохранение изменений тренировки
async function saveEditedTraining() {
    const id = document.getElementById('edit_training_id').value;
    const date = document.getElementById('edit_training_date').value;
    const time = document.getElementById('edit_training_time').value;
    const clientId = document.getElementById('edit_training_client_id').value;
    const trainerId = document.getElementById('edit_training_trainer_id').value;
    const status = document.getElementById('edit_training_status').value;
    const notes = document.getElementById('edit_training_notes').value;
    
    // Убираем предыдущие ошибки
    document.querySelectorAll('.input-error').forEach(el => {
        el.classList.remove('input-error');
    });
    
    // ВАЛИДАЦИЯ
    const dateCheck = validateTrainingDate(date);
    if (!dateCheck.valid) {
        document.getElementById('edit_training_date').classList.add('input-error');
        alert(dateCheck.message);
        return;
    }
    
    const timeCheck = validateTrainingTime(time);
    if (!timeCheck.valid) {
        document.getElementById('edit_training_time').classList.add('input-error');
        alert(timeCheck.message);
        return;
    }
    
    const clientCheck = validateSelect(clientId, 'клиента');
    if (!clientCheck.valid) {
        document.getElementById('edit_training_client_id').classList.add('input-error');
        alert(clientCheck.message);
        return;
    }
    
    const trainerCheck = validateSelect(trainerId, 'тренера');
    if (!trainerCheck.valid) {
        document.getElementById('edit_training_trainer_id').classList.add('input-error');
        alert(trainerCheck.message);
        return;
    }
    
    const notesCheck = validateNotes(notes);
    if (!notesCheck.valid) {
        document.getElementById('edit_training_notes').classList.add('input-error');
        alert(notesCheck.message);
        return;
    }
    
    // Проверяем, свободен ли тренер (исключая текущую тренировку)
    const availabilityCheck = await checkTrainerAvailability(trainerId, date, time, id);

    if (!availabilityCheck.available) {
        document.getElementById('edit_training_trainer_id').classList.add('input-error');
        alert(availabilityCheck.message || 'Тренер уже занят в это время. Нужно соблюдать интервал в 1 час между тренировками.');
        return;
    }
    
    const updatedTraining = {
        training_date: date,
        training_time: time,
        client_id: clientId,
        trainer_id: trainerId,
        status: status,
        notes: notes
    };
    
    try {
        const response = await fetch(`http://localhost:3000/api/trainings/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedTraining)
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Ошибка при обновлении');
        }
        
        cancelEditTraining();
        await loadTrainings();
        alert('Тренировка обновлена');
        
    } catch (error) {
        console.error('Ошибка:', error);
        alert('Не удалось обновить тренировку: ' + error.message);
    }
}