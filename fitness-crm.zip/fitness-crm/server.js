// Подключаем необходимые модули
const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const path = require('path');

function sanitizeInput(input) {
    if (input === null || input === undefined) return input;
    

    let str = String(input);
    
    str = str.replace(/[<>'";]/g, function(match) {

        const replacements = {
            '<': '&lt;',
            '>': '&gt;',
            "'": '&#39;',
            '"': '&quot;',
            ';': '&#59;'
        };
        return replacements[match] || match;
    });
    
    return str;
}


function validateInput(input, fieldName) {
    if (input === null || input === undefined) return input;
    
    const str = String(input);
    
    if (str.length > 1000) {
        throw new Error(`Поле ${fieldName} слишком длинное`);
    }
    
    return str;
}

// Создаем приложение
const app = express();
const port = 3000;

// Разрешаем запросы с других страниц
app.use(cors());
// Разрешаем получать JSON в запросах
app.use(express.json());
// Указываем, что HTML-файлы лежат в текущей папке
app.use(express.static(path.join(__dirname, './')));


const pool = new Pool({
    user: 'postgres',        
    host: 'localhost',       
    database: 'fitness_crm', 
    password: 'Dorami1221',    
    port: 5432,             ъ
});

// Проверка подключения к базе
pool.connect((err, client, release) => {
    if (err) {
        console.error('❌ ОШИБКА: Не удалось подключиться к базе данных');
        console.error(err.stack);
    } else {
        console.log('✅ УСПЕХ: Подключение к базе данных установлено');
        release();
    }
});

// ----- ЗАПРОСЫ К БАЗЕ ДАННЫХ (API) -----

// 1. ПОЛУЧИТЬ ВСЕХ КЛИЕНТОВ
// Адрес: http://localhost:3000/api/clients
app.get('/api/clients', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM clients ORDER BY id');
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка при получении клиентов' });
    }
});

// 2. ПОЛУЧИТЬ ВСЕХ ТРЕНЕРОВ
// Адрес: http://localhost:3000/api/trainers
app.get('/api/trainers', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM trainers ORDER BY id');
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка при получении тренеров' });
    }
});

// 3. ПОЛУЧИТЬ ВСЕ ТРЕНИРОВКИ (С ИМЕНАМИ КЛИЕНТОВ И ТРЕНЕРОВ)
// Адрес: http://localhost:3000/api/trainings
app.get('/api/trainings', async (req, res) => {
    try {
        // Сложный запрос, который соединяет три таблицы
        const result = await pool.query(`
            SELECT 
                t.id,
                t.training_date,
                t.training_time,
                t.status,
                t.client_id,
                t.trainer_id,
                c.last_name as client_last_name,
                c.first_name as client_first_name,
                tr.last_name as trainer_last_name,
                tr.first_name as trainer_first_name
            FROM trainings t
            JOIN clients c ON t.client_id = c.id
            JOIN trainers tr ON t.trainer_id = tr.id
            ORDER BY t.training_date, t.training_time
        `);
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка при получении тренировок' });
    }
});

// ПОЛУЧИТЬ ТРЕНИРОВКУ ПО ID
app.get('/api/trainings/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query(
            'SELECT * FROM trainings WHERE id = $1',
            [id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Тренировка не найдена' });
        }
        
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Ошибка при получении тренировки:', err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

// 4. ПОЛУЧИТЬ ЗАГРУЗКУ ТРЕНЕРОВ (сколько у каждого тренировок)
// Адрес: http://localhost:3000/api/trainer-load
app.get('/api/trainer-load', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT 
                t.id,
                t.last_name,
                t.first_name,
                t.specialization,
                COUNT(tr.id) as training_count
            FROM trainers t
            LEFT JOIN trainings tr ON t.id = tr.trainer_id 
                AND tr.status = 'scheduled'
            GROUP BY t.id
            ORDER BY training_count DESC
        `);
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка при получении загрузки тренеров' });
    }
});

// 5. ПРОВЕРИТЬ АКТИВЕН ЛИ АБОНЕМЕНТ У КЛИЕНТА
// Адрес: http://localhost:3000/api/check-abonement/1 (где 1 - ID клиента)
app.get('/api/check-abonement/:clientId', async (req, res) => {
    try {
        const { clientId } = req.params;
        const result = await pool.query(
            'SELECT abonement_end, visits_left FROM clients WHERE id = $1',
            [clientId]
        );
        
        if (result.rows.length === 0) {
            return res.json({ valid: false, reason: 'Клиент не найден' });
        }
        
        const client = result.rows[0];
        const today = new Date();
        const endDate = new Date(client.abonement_end);
        
        if (endDate < today) {
            return res.json({ valid: false, reason: 'Срок абонемента истек' });
        }
        
        if (client.visits_left !== null && client.visits_left <= 0) {
            return res.json({ valid: false, reason: 'Нет доступных посещений' });
        }
        
        res.json({ valid: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка при проверке абонемента' });
    }
});

// 6. ДОБАВИТЬ НОВОГО КЛИЕНТА
// Адрес: http://localhost:3000/api/clients (POST-запрос)
app.post('/api/clients', async (req, res) => {
    try {
        const { last_name, first_name, phone, abonement_type, abonement_end, visits_left } = req.body;
        const result = await pool.query(
            'INSERT INTO clients (last_name, first_name, phone, abonement_type, abonement_end, visits_left) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
            [last_name, first_name, phone, abonement_type, abonement_end, visits_left]
        );
        res.json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка при добавлении клиента' });
    }
});

// РЕГИСТРАЦИЯ НОВОГО ПОЛЬЗОВАТЕЛЯ
// РЕГИСТРАЦИЯ НОВОГО ПОЛЬЗОВАТЕЛЯ (с защитой)
app.post('/api/register', async (req, res) => {
    try {
        // Очищаем и валидируем входные данные
        const rawData = req.body;
        
        const last_name = sanitizeInput(rawData.last_name);
        const first_name = sanitizeInput(rawData.first_name);
        const phone = sanitizeInput(rawData.phone);
        const email = rawData.email ? sanitizeInput(rawData.email) : null;
        const username = sanitizeInput(rawData.username);
        const password = rawData.password; // пароль не очищаем, но проверим длину
        const role = sanitizeInput(rawData.role || 'user');
        
        // Валидация
        if (!last_name || !first_name || !phone || !username || !password) {
            return res.status(400).json({ error: 'Все обязательные поля должны быть заполнены' });
        }
        
        // Проверка длины
        if (last_name.length > 50) throw new Error('Фамилия слишком длинная');
        if (first_name.length > 50) throw new Error('Имя слишком длинное');
        if (username.length > 50) throw new Error('Логин слишком длинный');
        if (password.length < 6) throw new Error('Пароль должен быть не менее 6 символов');
        
        // Проверяем телефон (только цифры)
        const phoneDigits = phone.replace(/\D/g, '');
        if (phoneDigits.length !== 11) {
            return res.status(400).json({ error: 'Неверный формат телефона' });
        }
        
        // Проверяем, не занят ли логин (используем параметризованный запрос)
        const checkUser = await pool.query(
            'SELECT * FROM users WHERE username = $1',
            [username]  // ← параметризованный запрос
        );
        
        if (checkUser.rows.length > 0) {
            return res.status(400).json({ error: 'Пользователь с таким логином уже существует' });
        }
        
        // Добавляем нового пользователя (параметризованный запрос)
        const result = await pool.query(
            `INSERT INTO users (username, password, role, full_name, last_login, is_active) 
             VALUES ($1, $2, $3, $4, NULL, true) RETURNING id, username, role`,
            [username, password, role, `${last_name} ${first_name}`]  // ← параметры
        );
        
        res.json({ 
            success: true, 
            user: result.rows[0],
            message: 'Регистрация успешна' 
        });
        
    } catch (err) {
        console.error('Ошибка регистрации:', err);
        res.status(500).json({ error: err.message || 'Ошибка при регистрации' });
    }
});

// ДОБАВИТЬ НОВОГО КЛИЕНТА (с защитой)
app.post('/api/clients', async (req, res) => {
    try {
        const rawData = req.body;
        
        // Очищаем входные данные
        const last_name = sanitizeInput(rawData.last_name);
        const first_name = sanitizeInput(rawData.first_name);
        const phone = sanitizeInput(rawData.phone);
        const abonement_type = sanitizeInput(rawData.abonement_type);
        const abonement_end = rawData.abonement_end;
        const visits_left = rawData.visits_left ? parseInt(rawData.visits_left) : null;
        
        // Валидация
        if (!last_name || !first_name || !phone || !abonement_type || !abonement_end) {
            return res.status(400).json({ error: 'Все обязательные поля должны быть заполнены' });
        }
        
        // Проверка телефона
        const phoneDigits = phone.replace(/\D/g, '');
        if (phoneDigits.length !== 11) {
            return res.status(400).json({ error: 'Неверный формат телефона' });
        }
        
        // Параметризованный запрос (безопасно)
        const result = await pool.query(
            'INSERT INTO clients (last_name, first_name, phone, abonement_type, abonement_end, visits_left) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
            [last_name, first_name, phoneDigits, abonement_type, abonement_end, visits_left]
        );
        
        res.json(result.rows[0]);
        
    } catch (err) {
        console.error('Ошибка при добавлении клиента:', err);
        res.status(500).json({ error: 'Ошибка при добавлении клиента' });
    }
});

// СОЗДАНИЕ НОВОЙ ТРЕНИРОВКИ
app.post('/api/trainings', async (req, res) => {
    try {
        const { training_date, training_time, client_id, trainer_id, notes } = req.body;
        
        // Проверяем абонемент
        const checkResult = await pool.query(
            'SELECT abonement_end, visits_left FROM clients WHERE id = $1',
            [client_id]
        );
        
        if (checkResult.rows.length === 0) {
            return res.status(400).json({ error: 'Клиент не найден' });
        }
        
        const client = checkResult.rows[0];
        const today = new Date();
        const endDate = new Date(client.abonement_end);
        
        if (endDate < today) {
            return res.status(400).json({ error: 'Срок абонемента истек' });
        }
        
        if (client.visits_left !== null && client.visits_left <= 0) {
            return res.status(400).json({ error: 'Нет доступных посещений' });
        }
        
        // Создаем тренировку
        const result = await pool.query(
            `INSERT INTO trainings (training_date, training_time, client_id, trainer_id, status, notes) 
             VALUES ($1, $2, $3, $4, 'scheduled', $5) RETURNING *`,
            [training_date, training_time, client_id, trainer_id, notes]
        );
        
        res.json(result.rows[0]);
        
    } catch (err) {
        console.error('Ошибка создания тренировки:', err);
        res.status(500).json({ error: 'Ошибка при создании тренировки' });
    }
});

// ОБНОВИТЬ СТАТУС ТРЕНИРОВКИ (с проверкой конфликтов)
app.patch('/api/trainings/:id/status', async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        
        // Получаем данные тренировки
        const trainingData = await pool.query(
            'SELECT * FROM trainings WHERE id = $1',
            [id]
        );
        
        if (trainingData.rows.length === 0) {
            return res.status(404).json({ error: 'Тренировка не найдена' });
        }
        
        const training = trainingData.rows[0];
        
        // Если пытаемся активировать отмененную тренировку
        if (training.status === 'cancelled' && (status === 'scheduled' || status === 'completed')) {
            
            // Проверяем, нет ли другой тренировки в это же время у этого тренера
            const [hours, minutes] = training.training_time.split(':').map(Number);
            const trainingTimeInMinutes = hours * 60 + minutes;
            
            const startBoundary = trainingTimeInMinutes - 60;
            const endBoundary = trainingTimeInMinutes + 60;
            
            const startHour = Math.floor(startBoundary / 60);
            const startMinute = startBoundary % 60;
            const endHour = Math.floor(endBoundary / 60);
            const endMinute = endBoundary % 60;
            
            const startTimeStr = `${String(startHour).padStart(2, '0')}:${String(startMinute).padStart(2, '0')}`;
            const endTimeStr = `${String(endHour).padStart(2, '0')}:${String(endMinute).padStart(2, '0')}`;
            
            const conflictCheck = await pool.query(
                `SELECT id, client_id, status FROM trainings 
                 WHERE trainer_id = $1 
                 AND training_date = $2 
                 AND status = 'scheduled'
                 AND id != $3
                 AND training_time BETWEEN $4 AND $5`,
                [training.trainer_id, training.training_date, id, startTimeStr, endTimeStr]
            );
            
            if (conflictCheck.rows.length > 0) {
                const conflict = conflictCheck.rows[0];
                return res.status(409).json({ 
                    error: 'Нельзя активировать тренировку: время уже занято другим клиентом',
                    conflictingTraining: conflict
                });
            }
        }
        
        // Обновляем статус
        const result = await pool.query(
            'UPDATE trainings SET status = $1 WHERE id = $2 RETURNING *',
            [status, id]
        );
        
        res.json(result.rows[0]);
        
    } catch (err) {
        console.error('Ошибка обновления статуса:', err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

// ПОЛНОЕ ОБНОВЛЕНИЕ ТРЕНИРОВКИ
app.put('/api/trainings/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { training_date, training_time, client_id, trainer_id, status, notes } = req.body;
        
        const result = await pool.query(
            `UPDATE trainings 
             SET training_date = $1, 
                 training_time = $2, 
                 client_id = $3, 
                 trainer_id = $4, 
                 status = $5, 
                 notes = $6
             WHERE id = $7 
             RETURNING *`,
            [training_date, training_time, client_id, trainer_id, status, notes, id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Тренировка не найдена' });
        }
        
        res.json(result.rows[0]);
        
    } catch (err) {
        console.error('Ошибка полного обновления:', err);
        res.status(500).json({ error: 'Ошибка при обновлении' });
    }
});


// УДАЛИТЬ ТРЕНИРОВКУ
app.delete('/api/trainings/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query(
            'DELETE FROM trainings WHERE id = $1 RETURNING *',
            [id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Тренировка не найдена' });
        }
        
        res.json({ success: true, message: 'Тренировка удалена' });
        
    } catch (err) {
        console.error('Ошибка удаления тренировки:', err);
        res.status(500).json({ error: 'Ошибка при удалении' });
    }
});

// ПОЛУЧИТЬ КЛИЕНТА ПО ID
app.get('/api/clients/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM clients WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Клиент не найден' });
        }
        
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Ошибка при получении клиента:', err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

// ОБНОВИТЬ КЛИЕНТА
app.put('/api/clients/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { last_name, first_name, middle_name, phone, email, abonement_type, abonement_end, visits_left } = req.body;
        
        // Валидация
        if (!last_name || !first_name || !phone || !abonement_type || !abonement_end) {
            return res.status(400).json({ error: 'Заполните все поля' });
        }
        
        const phoneDigits = phone.replace(/\D/g, '');
        if (phoneDigits.length !== 11) {
            return res.status(400).json({ error: 'Телефон должен содержать 11 цифр' });
        }
        
        const result = await pool.query(
            `UPDATE clients 
             SET last_name = $1, 
                 first_name = $2, 
                 middle_name = $3, 
                 phone = $4, 
                 email = $5, 
                 abonement_type = $6, 
                 abonement_end = $7, 
                 visits_left = $8
             WHERE id = $9 
             RETURNING *`,
            [
                last_name, 
                first_name, 
                middle_name || null, 
                phoneDigits, 
                email || null, 
                abonement_type, 
                abonement_end, 
                visits_left || null,
                id
            ]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Клиент не найден' });
        }
        
        res.json(result.rows[0]);
        
    } catch (err) {
        console.error('Ошибка обновления клиента:', err);
        res.status(500).json({ error: 'Ошибка при обновлении' });
    }
});

// УДАЛИТЬ КЛИЕНТА
app.delete('/api/clients/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        // Проверяем, есть ли у клиента тренировки
        const checkTrainings = await pool.query(
            'SELECT id FROM trainings WHERE client_id = $1',
            [id]
        );
        
        if (checkTrainings.rows.length > 0) {
            return res.status(400).json({ 
                error: 'Нельзя удалить клиента, у него есть тренировки' 
            });
        }
        
        const result = await pool.query(
            'DELETE FROM clients WHERE id = $1 RETURNING *',
            [id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Клиент не найден' });
        }
        
        res.json({ success: true, message: 'Клиент удален' });
        
    } catch (err) {
        console.error('Ошибка удаления клиента:', err);
        res.status(500).json({ error: 'Ошибка при удалении' });
    }
});


app.post('/api/check-trainer-availability', async (req, res) => {
    try {
        const { trainer_id, training_date, training_time, exclude_training_id } = req.body;
        
        const [hours, minutes] = training_time.split(':').map(Number);
        const trainingTimeInMinutes = hours * 60 + minutes;
        
        const startBoundary = trainingTimeInMinutes - 60;
        const endBoundary = trainingTimeInMinutes + 60;
        
        const startHour = Math.floor(startBoundary / 60);
        const startMinute = startBoundary % 60;
        const endHour = Math.floor(endBoundary / 60);
        const endMinute = endBoundary % 60;
        
        const startTimeStr = `${String(startHour).padStart(2, '0')}:${String(startMinute).padStart(2, '0')}`;
        const endTimeStr = `${String(endHour).padStart(2, '0')}:${String(endMinute).padStart(2, '0')}`;
        
        console.log(`Проверка интервала для тренера ${trainer_id} с ${startTimeStr} до ${endTimeStr}`);
        
        let query = `
            SELECT id, training_time, status FROM trainings 
            WHERE trainer_id = $1 
            AND training_date = $2 
            AND status = 'scheduled'  -- ТОЛЬКО ЗАПЛАНИРОВАННЫЕ
            AND (
                training_time >= $3 AND training_time <= $4
            )
        `;
        let params = [trainer_id, training_date, startTimeStr, endTimeStr];
        
        if (exclude_training_id) {
            query += ` AND id != $5`;
            params.push(exclude_training_id);
        }
        
        const result = await pool.query(query, params);
        
        if (result.rows.length > 0) {
            const conflictTime = result.rows[0].training_time;
            return res.json({ 
                available: false,
                message: `Тренер уже занят в ${conflictTime}. Нужно соблюдать интервал в 1 час между тренировками.`,
                conflictingTraining: result.rows[0]
            });
        }
        
        res.json({ 
            available: true,
            message: 'Время свободно'
        });
        
    } catch (err) {
        console.error('Ошибка проверки доступности тренера:', err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

// ЗАПУСК СЕРВЕРА
app.listen(port, () => {
    console.log(`🚀 Сервер запущен!`);
    console.log(`📂 Открой в браузере: http://localhost:${port}`);
    console.log(`📋 Список клиентов: http://localhost:${port}/clients.html`);
});